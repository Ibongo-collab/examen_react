class Maillot {
    constructor(reference, description, marque, prix) {
      this.reference = reference;
      this.description = description;
      this.marque = marque;
      this.prix = prix;
    }
  }
  
  export default Maillot;